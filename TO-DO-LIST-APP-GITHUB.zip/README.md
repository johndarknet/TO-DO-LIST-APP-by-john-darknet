# To-Do List App

📝 A simple web-based to-do list application with due dates and notifications.

## Features
- Add and remove tasks easily
- Set due dates and reminder notifications
- Works directly in your browser (no installation)
- Responsive and simple design

## Credits
Created by **John Darknet**
